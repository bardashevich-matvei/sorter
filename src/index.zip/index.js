class Sorter {
  constructor() {
    this.array=[];
  }

  add(element) {
    this.array.push(element);
  }

  at(index) {
    return this.array[index];
  }

  get length() {
    return this.array.length;
  }

  toArray() {
    return this.array;
  }

  sort(indices) {
      let mas=[];
      mas=this.array.slice(Math.min.apply(null, indices), Math.max.apply(null, indices)+1);
      mas.sort(function compareFunction(a, b) { 
        return a-b; 
      }); 
      mas.forEach((item, i, indices) => this.array[item]=mas[i]);
    /*let mas=[];
    this.array.forEach(function(item, i, indices){
      mas.push(this.array[item]);
    });
    mas.sort(function compareFunction(a, b) {
      return a-b;
    });
    mas.forEach(function(item, i, indices){
      this.array[item]=mas[i];
    });*/
  }

  setComparator(compareFunction) {
    // your implementation
  }
}

module.exports = Sorter;